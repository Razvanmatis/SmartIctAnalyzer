﻿using System.Windows;

namespace MVVMLoginDialog
{
    public partial class LoginView : Window
    {
        public LoginView()
        {
            InitializeComponent();
        }
    }
}
