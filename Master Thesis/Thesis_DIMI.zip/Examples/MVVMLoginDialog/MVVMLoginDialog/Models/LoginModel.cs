﻿using Prism.Mvvm;

namespace MVVMLoginDialog.Models
{
    public class LoginModel : BindableBase
    {
        private string userName = string.Empty;
        public string UserName
        {
            get
            {
                return userName;
            }

            set
            {
                SetProperty(ref userName, value);
            }
        }

        private string password = string.Empty;
        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                SetProperty(ref password, value);
            }
        }
    }
}
