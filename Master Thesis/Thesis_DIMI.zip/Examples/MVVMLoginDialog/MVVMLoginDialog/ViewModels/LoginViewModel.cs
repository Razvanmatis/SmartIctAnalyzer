﻿using MVVMLoginDialog.Models;
using Prism.Commands;
using Prism.Mvvm;
using System.Windows.Input;

namespace MVVMLoginDialog.ViewModels
{
    public class LoginViewModel : BindableBase
    {
        private LoginModel user = new ();
        public LoginModel User
        {
            get
            {
                return user;
            }

            set
            {
                SetProperty(ref user, value);
            }
        }

        private ICommand login;
        public ICommand Login
        {
            get
            {
                return login;
            }

            set
            {
                SetProperty(ref login, value);
            }
        }

        public LoginViewModel()
        {
            Login = new DelegateCommand(PerformLogin, CanPerformLogin)
                .ObservesProperty(() => User.UserName)
                .ObservesProperty(() => User.Password);
        }

        private void PerformLogin()
        {
            // e.g. database operation...
        }

        private bool CanPerformLogin()
        {
            return User.UserName.Length > 0 
                && User.Password.Length > 0;
        }
    }
}
